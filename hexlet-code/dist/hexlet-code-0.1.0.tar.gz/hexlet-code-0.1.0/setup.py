# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hexlet_code', 'hexlet_code.page_analyzer']

package_data = \
{'': ['*'], 'hexlet_code.page_analyzer': ['templates/*']}

install_requires = \
['Flask>=2.3.2,<3.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'postgres>=4.0,<5.0',
 'psycopg2-binary>=2.9.6,<3.0.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'tyranich',
    'author_email': 'tyranich@mail.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
